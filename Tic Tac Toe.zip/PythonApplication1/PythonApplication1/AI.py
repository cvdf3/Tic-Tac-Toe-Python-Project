from Board import Board
from time import sleep
import itertools, pprint, os

class AI:

    def __init__(self, playerTurn, value, board):
        self.playerTurn = -1
        self.value = 0

    #_______________________________________________________________________
    #the order of the game
    def turnOrder(self, board, player, comp):
        results = board.isWinner()

        #there is not a winner
        while abs(results[-1]) != 1 and results[-1] != 2:
            
            os.system('cls')
            board.viewBoard()

            #HELPERS__
            #print()
            #board.viewActualBoard()
            #print(results)

            #AI turn
            if self.playerTurn == 1:
                self.aiTree(board, comp, results)

            #player turn
            else:
                board.playerMove(player)
            
            #recheck for winner
            results = board.isWinner()

            #HELPERS__
            #print(returnData)
            #print(results) ; sleep(4)#

            #switch players
            self.playerTurn *= -1

        #there is a winner
        return results[-1]
    #_______________________________________________________________________

    def aiTree(self, board, comp, turnResults):
        
        move = False

        #determines which row, col, or diag has the highest sum, or which is closest to winning
        #whether it is the player or computer, it will try to fill the remaining spaces
        maxRows = abs(max(turnResults[0]))
        maxRowsIndex = turnResults[0].index(max(turnResults[0])) 
        maxCols = abs(max(turnResults[1]))
        maxColsIndex = turnResults[1].index(max(turnResults[1]))
        maxDiag1 = abs(turnResults[2])
        maxDiag2 = abs(turnResults[3])
        highest = max(maxRows, maxCols, maxDiag1, maxDiag2)
        
        #HELPERS__
        #print(turnResults)
        #print(maxRows, ' ', maxRowsIndex, ' ', maxCols, ' ', maxColsIndex, 
        #      ' ', maxDiag1, ' ', maxDiag2) ; sleep(10)
        #use turnResults to find the index of the highest total row and have it search for a blank box there

        #diagonals are the most important positions, so they are prioritized
        if maxDiag1 == highest:
            for i in range(board.d):
                if board.rows[i][i][1] == 0:
                    board.rows[i][i][0] = comp
                    board.rows[i][i][1] = 1
                    break
        elif maxDiag2 == highest:
            for i in range(board.d - 1, -1, -1):
               if board.rows[i][-i - 1][1] == 0:
                   board.rows[i][-i - 1][0] = comp
                   board.rows[i][-i - 1][1] = 1
                   break
        elif maxRows == highest:
            for i in range(board.d):
                if board.rows[maxRowsIndex][i][1] == 0:
                    board.rows[maxRowsIndex][i][0] = comp
                    board.rows[maxRowsIndex][i][1] = 1
                    break
        else:
            for i in range(board.d):
                if board.rows[i][maxColsIndex][1] == 0:
                    board.rows[i][maxColsIndex][0] = comp
                    board.rows[i][maxColsIndex][1] = 1
                    break