from time import sleep
import numpy as np
import itertools, pprint, os

class Board:

    #define the board, self, dimension of rows(r) & columns(c), boxes and rows will be redefined after
    def __init__(self, d, rows):
        self.d = d
        self.rows = []

    #get the definitons of the table
    def getDef():
        print('Please enter the size of the board you would like to play on.')
        num = input()
        if num.isdigit() and int(num) < 21: #checks if input is a number and less than 21
            os.system('cls')
            return int(num)
        else:
            os.system('cls')
            return Board.getDef()   #recursively recall the method to get them to pick a different input

    #create the board using the dimensions (d)
    def buildBoard(self):

        rows = [[[' ', 0] for j in range(self.d)] for i in range(self.d)] #builds the board based on the player input

        self.rows = rows
        return self

    #   [row][box][index]
    #   a column [first row][box] [second row][box] [third row][box], etc

    #player's move, currently limited to 3x3 board
    def playerMove(self, player):

        print('Make your move')
        pick = input()

        if pick == '1' and self.rows[2][0][1] == 0:
            self.rows[2][0][0] = player
            self.rows[2][0][1] = -1
        elif pick == '7' and self.rows[0][0][1] == 0:
            self.rows[0][0][0] = player
            self.rows[0][0][1] = -1
        elif pick == '9' and self.rows[0][2][1] == 0:
            self.rows[0][2][0] = player
            self.rows[0][2][1] = -1
        elif pick == '3' and self.rows[2][2][1] == 0:
            self.rows[2][2][0] = player
            self.rows[2][2][1] = -1
        elif pick == '5' and self.rows[1][1][1] == 0:
            self.rows[1][1][0] = player
            self.rows[1][1][1] = -1
        elif pick == '4' and self.rows[1][0][1] == 0:
            self.rows[1][0][0] = player
            self.rows[1][0][1] = -1
        elif pick == '2' and self.rows[2][1][1] == 0:
            self.rows[2][1][0] = player
            self.rows[2][1][1] = -1
        elif pick == '6' and self.rows[1][2][1] == 0:
            self.rows[1][2][0] = player
            self.rows[1][2][1] = -1
        elif pick == '8' and self.rows[0][1][1] == 0:
            self.rows[0][1][0] = player
            self.rows[0][1][1] = -1
        else:
            print('You can\'t move there...'); sleep(1)
            self.playerMove(player)

    #check if there is a winner
    #__________________________________________________
    def isWinner(self):
        sum1 = 0
        rowSum = []
        sum2 = 0
        colSum = []
        sum3 = 0
        sum4 = 0
        tie = 0
        win = 0

        #check rows using sum1

        for i in range(self.d):
            for j in range(self.d):
                sum1 += self.rows[i][j][1]
                if abs(sum1) == self.d: #checks if the absolute value is equal to the board dimensions 
                                            #(or if a row has all of the same letters in it)
                    win = sum1 // self.d    #win will equal 1 or -1, depending on who filled the row
                elif (j + 1) % self.d == 0: #places the sum into an array, 
                    rowSum.append(abs(sum1))    #so the highest row can be determined by it's index
                    sum1 = 0

        #check columns using sum2

        for i in range(self.d):
            for j in range(self.d):
                sum2 += self.rows[j][i][1]
                if abs(sum2) == self.d:
                    win = sum2 // self.d
                elif (j + 1) % self.d == 0:
                    colSum.append(abs(sum2))
                    sum2 = 0
                                             
        #check left to right diagonal using sum3

        for i in range(self.d):
            sum3 += self.rows[i][i][1]
        if abs(sum3) == self.d:
            win = sum3 // self.d

        #check right to left diagonal using sum4

        for i in range(self.d - 1, -1, -1):
            sum4 += self.rows[i][-i - 1][1]
        if abs(sum4) == self.d:
            win = sum4 // self.d

        #check for tie
        if win != 1:
            for i in range(self.d):
                for j in range(self.d):
                    if self.rows[i][j][1] != 0:
                        tie += 1
            if tie == self.d ** 2:
                win = 2
            else:
                tie = 0

        return [rowSum, colSum, sum3, sum4, win]
    #__________________________________________________

    #view the board as it is in the program
    def viewActualBoard(self):
        for i in range(self.d):
            print(self.rows[i])

    #view the board as the player sees it
    def viewBoard(self):
        for i in range(self.d):
            for j in range(self.d):
                print('|_', self.rows[i][j][0], sep = '', end = '_|')
                if (j + 1) % self.d == 0:
                    print('\n')
                