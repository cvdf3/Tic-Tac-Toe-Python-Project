from AI import AI
from Board import Board
from time import sleep
import os

quit = False
bd = Board(0, 0)
ai = AI(-1, 0, bd)

while quit == False:

    #Start the game, choose board size

    print('Welcome to Tic Tac Toe! Would you like to play on a normal sized board?')

    if 'n' in input():
        bd = Board(Board.getDef(), 0)   #create the board dimensions based on the player's input
    else:
        os.system('cls')
        bd = Board(3, 0)

    #choose player character
    print('What character would you like to be?')

    playerChar = (input()[0]).upper()   #takes the first letter of the input and makes it the player's character
    os.system('cls')
    print('You will be ', playerChar, '.\n\n'
          'You go first.', sep = '')
    
    #get computer's character, changes to X if the player is already O
    if playerChar != 'O': #not being O is the most likely case, so it is prioritized
        compChar = 'O'
    else:
        compChar = 'X'
    sleep(2)
    os.system('cls')

    #creates the board from the values chosen by the player
    bd.buildBoard()

    #creates the AI for the game, with the depth being the number of turns left or the total squares on the board
    game = ai.turnOrder(bd, playerChar, compChar)

    if game == 2:
        print('You tied...')
    elif game == 1:
        print('Sorry you lose')
    else:
        print('Congratulations, you won!')

    sleep(2) ; os.system('cls')
    print('Would you like to play again?')
    if 'n' in input():
        os.system('cls')
        print('Thank you for playing!') ; sleep(3)
        quit = True

    os.system('cls')

#________________________________________________________________________________
#TEST__
#for i in range(bd.d):
#for i in range(bd.d - 1, -1, -1):
#    #for j in range(bd.d):
#    bd.rows[i][-i - 1][1] = -1
#    bd.rows[i][-i - 1][0] = playerChar

#HELPERS__
#
#bd.viewActualBoard()
#print()#
#bd.viewBoard()
#print()#
#print(bd.isWinner())
#print()#
#print(sum(bd.isWinner()[0]), '\n', sum(bd.isWinner()[1]), sep = '')
#
#print(bd.boxes[0][0])        #prints the first element, in the first box
#print(bd.boxes[0])           #prints the array of the first key, this represents the first box
#print(bd.boxes)              #prints a row of boxes
#
#print(bd.rows[0][0][0])      #prints the first element, in the first box, of the first row
#print(bd.rows[0][0])         #prints the array of the first box, in the first row
#print(bd.rows[0])            #prints first row
#print(bd.rows)               #prints all of the rows, this is the entire 
#
#                             #rows[0][0], rows[1][0], rows[2][0] makes the first column, 
#                             #as it is taking the first box of each row